<?php 
class Student{
	public $stuName;
	public $stuRegNumber;

	function __construct($stuName,$stuRegNumber){ 
        $this->stuName=$stuName; 
        $this->stuRegNumber=$stuRegNumber;
    } 

    function display() 
    { 
        echo "Student Name is ".$this->stuName."\n"; 
        echo "Registration Number is ".$this->stuRegNumber; 
    }
}
$stu1= new Student("Kamal","ICT01"); 
$stu1->display(); 
echo "</br>";
echo "</br>";

$stu2= new Student("akmal","ICT02"); 
$stu2->display(); 
echo "</br>";
echo "</br>";

$stu3= new Student("Kumuthu","ICT03"); 
$stu3->display(); 
echo "</br>";
echo "</br>";

$stu4= new Student("raja","ICT04"); 
$stu4->display(); 
 ?>