abstract class Employee{
	String name;
	int id;
	Employee(int id, String name){
		this.id=id;
		this.name=name;
	}
	void displayDetails(){
		System.out.println("Id: "+id+"    Name: "+name);
	}
}
class Engineer extends Employee{
	Engineer(){
		super(045,"Dakshitha");	
	}
	public static void main(String[] args) {
		Engineer eng = new Engineer();
		eng.displayDetails();
	}
}