abstract class Calculation{
	abstract int cal(int x, int y);

	public static void main(String[] args) {
		Addition add = new Addition();
		System.out.println(add.cal(2,5));
		Subtraction subt = new Subtraction();
		System.out.println(subt.cal(10,4));
		Multiplication mult = new Multiplication();
		System.out.println(mult.cal(3,5));
		Division div = new Division();
		System.out.println(div.cal(15,5));
	}
}
class Addition extends Calculation{
	int cal(int x,int y){
		return x+y;
	}
}
class Subtraction extends Calculation{
	int cal(int x,int y){
		return x-y;
	}
}
class Multiplication extends Calculation{
	int cal(int x,int y){
		return x*y;
	}
}
class Division extends Calculation{
	int cal(int x,int y){
		return x/y;
	}
}