
package calculation;
abstract class Employee{
    int id;
    String name;
    
    Employee(int id, String name){
        this.id = id;
        this.name = name;
    }
    
    void displayDetails(){
        System.out.println("Id is :"+id+"\nName is : "+name);
    }
}


public class Engineer extends Employee{
    Engineer(){
        super(01, "Kanishka");
    }
    
    public static void main(String[] args) {
        Engineer eng = new Engineer();
        eng.displayDetails();
    }
}
