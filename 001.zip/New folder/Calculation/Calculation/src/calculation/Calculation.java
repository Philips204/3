
package calculation;

abstract class Calculate{
    abstract double calculate(int a, int b);
}
class Addition extends Calculate{
    public double calculate(int a, int b){
        return a + b;
    }
}

class Multification extends Calculate{
    public double calculate(int a, int b){
        return a * b;
    }
}

class Divition extends Calculate{
    public double calculate(int a, int b){
        return a / b;
    }
}

class Subtraction extends Calculate{
    public double calculate(int a, int b){
        return a - b;
    }
}

public class Calculation {

    public static void main(String[] args) {
        Addition add = new Addition();
        Multification mult = new Multification();
        Divition div = new Divition();
        Subtraction sub = new Subtraction();
        
        System.out.println("Addition is : "+add.calculate(5, 5));
        System.out.println("Multification is : "+mult.calculate(5, 5));
        System.out.println("Divition is : "+div.calculate(5, 5));
        System.out.println("Substraction is : "+sub.calculate(5, 2));
        
    }
    
}
