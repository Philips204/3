
package testcylinder;
class Circle{
    double radius;
    String color;
    
    Circle(){
        radius = 1.0;
        color = "Green";
    }
    
    Circle(double radius){
        this.radius = radius;
    }
    
    Circle(double radius, String color){
        this.radius = radius;
        this.color = color;
    }
    
    public double getRadius(){
        return radius;
    }
    
    public String getColor(String color){
        return color;
    }
    
    public void setRadius(double radius){
        this.radius = radius;
    }
    
    public void setColor(String color){
        this.color = color;  
    }
    
    public double getArea(){
        return radius * radius * 3.14;
    }
    
}

class Cylinder extends Circle{
    double height;
    
    Cylinder(){
        super();
        height = 1.0;
    }
    
    Cylinder(double height){
        super();
        this.height = height;
    }
    
    Cylinder(double height, double radius){
        super(radius);
        this.height = height;
    }
    
    Cylinder(double height, double radius, String color){
        super(radius,color);
        this.height = height;
    }
    
    public double getHeight(){
        return height;
    }
    public void setHeight(double height){
        this.height = height;
    }
    
    public double getVolume(){
        return getArea() * height;
    }   
}



public class TestCylinder {

    public static void main(String[] args) {
       Cylinder cylinder1 = new Cylinder();
        System.out.println("Radius is "+cylinder1.radius);
        System.out.println("Color is "+cylinder1.color);
        System.out.println("Height is "+cylinder1.height);
        System.out.println("Area is "+cylinder1.getArea());
        System.out.println("Volume is "+cylinder1.getVolume());
        System.out.println();
        System.out.println();
        
        Cylinder cylinder2 = new Cylinder(7,10,"red");
        System.out.println("Radius is "+cylinder2.radius);
        System.out.println("Color is "+cylinder2.color);
        System.out.println("Height is "+cylinder2.height);
        System.out.println("Area is "+cylinder2.getArea());
        System.out.println("Volume is "+cylinder2.getVolume());
    }
    
}
